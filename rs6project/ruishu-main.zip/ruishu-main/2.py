for i in range(1):
    print(2)